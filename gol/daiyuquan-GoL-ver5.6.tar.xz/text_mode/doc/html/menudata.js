var menudata={children:[
{text:"Page principale",url:"index.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Liste des classes",url:"annotated.html"},
{text:"Index des classes",url:"classes.html"},
{text:"Membres de classe",url:"functions.html",children:[
{text:"Tout",url:"functions.html"},
{text:"Variables",url:"functions_vars.html"}]}]},
{text:"Fichiers",url:"files.html",children:[
{text:"Liste des fichiers",url:"files.html"},
{text:"Membres de fichier",url:"globals.html",children:[
{text:"Tout",url:"globals.html"},
{text:"Fonctions",url:"globals_func.html"},
{text:"Variables",url:"globals_vars.html"}]}]}]}
