var searchData=
[
  ['evolue',['evolue',['../jeu_8h.html#a0c11950a46b53162b21b35f8e36757fa',1,'evolue(grille *g, grille *gc, int(*compte_voisins_vivants)(int, int, grille), int vieillissement):&#160;jeu.c'],['../jeu_8c.html#a0c11950a46b53162b21b35f8e36757fa',1,'evolue(grille *g, grille *gc, int(*compte_voisins_vivants)(int, int, grille), int vieillissement):&#160;jeu.c']]]
];
