var searchData=
[
  ['sizex',['SIZEX',['../io_8h.html#a3d6d12a6ee0d7d77f3f180ed1b2a1e22',1,'io.h']]],
  ['sizey',['SIZEY',['../io_8h.html#a7e1991fcd344daa8c9e423cfd3481a8c',1,'io.h']]]
];
