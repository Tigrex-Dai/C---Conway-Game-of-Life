var searchData=
[
  ['compte_5fvoisins_5fvivants_5fc',['compte_voisins_vivants_c',['../jeu_8h.html#acc8422b6280ed6ef09f609683310de92',1,'compte_voisins_vivants_c(int i, int j, grille g):&#160;jeu.c'],['../jeu_8c.html#acc8422b6280ed6ef09f609683310de92',1,'compte_voisins_vivants_c(int i, int j, grille g):&#160;jeu.c']]],
  ['compte_5fvoisins_5fvivants_5fnc',['compte_voisins_vivants_nc',['../jeu_8h.html#a22938221cd19d43dde7cd8fa18e9b3fd',1,'compte_voisins_vivants_nc(int i, int j, grille g):&#160;jeu.c'],['../jeu_8c.html#a22938221cd19d43dde7cd8fa18e9b3fd',1,'compte_voisins_vivants_nc(int i, int j, grille g):&#160;jeu.c']]],
  ['copie_5fgrille',['copie_grille',['../grille_8h.html#a4562474d3f481fa7da7133925c37b99b',1,'copie_grille(grille *gs, grille *gd):&#160;grille.c'],['../grille_8c.html#a4562474d3f481fa7da7133925c37b99b',1,'copie_grille(grille *gs, grille *gd):&#160;grille.c']]]
];
