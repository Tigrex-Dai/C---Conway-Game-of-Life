var searchData=
[
  ['affiche_5fcairo_5ftext',['affiche_cairo_text',['../io_8h.html#a09f1f9ebde686da54bf440c149be532d',1,'affiche_cairo_text(int x, int y, char *text):&#160;io.c'],['../io_8c.html#a09f1f9ebde686da54bf440c149be532d',1,'affiche_cairo_text(int x, int y, char *text):&#160;io.c']]],
  ['affiche_5fcellule',['affiche_cellule',['../io_8h.html#a1f465e0c96abf80471766204b50b071c',1,'affiche_cellule(int x, int y, int val, int vieillissement):&#160;io.c'],['../io_8c.html#a1f465e0c96abf80471766204b50b071c',1,'affiche_cellule(int x, int y, int val, int vieillissement):&#160;io.c']]],
  ['affiche_5fgrille',['affiche_grille',['../io_8h.html#a3fbc5daf7726bc8805bf43deebd992df',1,'affiche_grille(grille g, char *modec, char *modev, int vieillissement):&#160;io.c'],['../io_8c.html#a3fbc5daf7726bc8805bf43deebd992df',1,'affiche_grille(grille g, char *modec, char *modev, int vieillissement):&#160;io.c']]],
  ['affiche_5fligne',['affiche_ligne',['../io_8h.html#a0f5ec4fd3b3993b83114188fb065bedd',1,'affiche_ligne(int x, int y, int *ligne, int vieillissement):&#160;io.c'],['../io_8c.html#a0f5ec4fd3b3993b83114188fb065bedd',1,'affiche_ligne(int x, int y, int *ligne, int vieillissement):&#160;io.c']]],
  ['affiche_5fosc',['affiche_osc',['../io_8h.html#a312d20304b2ce3d21b8c9b6f1c7e7495',1,'affiche_osc(grille *g, grille *gc):&#160;io.c'],['../io_8c.html#a312d20304b2ce3d21b8c9b6f1c7e7495',1,'affiche_osc(grille *g, grille *gc):&#160;io.c']]],
  ['alloue_5fgrille',['alloue_grille',['../grille_8h.html#ae621f51c60aa4fafaa0c9f6c9b5a4036',1,'alloue_grille(int l, int c, grille *g):&#160;grille.c'],['../grille_8c.html#ae621f51c60aa4fafaa0c9f6c9b5a4036',1,'alloue_grille(int l, int c, grille *g):&#160;grille.c']]]
];
