var searchData=
[
  ['init_5fgrille_5ffrom_5ffile',['init_grille_from_file',['../grille_8h.html#ac247d94af4c53fe64b28236f0a507bf0',1,'init_grille_from_file(char const *const filename, grille *g):&#160;grille.c'],['../grille_8c.html#ac247d94af4c53fe64b28236f0a507bf0',1,'init_grille_from_file(char const *const filename, grille *g):&#160;grille.c']]],
  ['init_5fsurface',['init_surface',['../io_8h.html#a7488d6302931e47bb5516246528ba930',1,'init_surface():&#160;io.c'],['../io_8c.html#a7488d6302931e47bb5516246528ba930',1,'init_surface():&#160;io.c']]],
  ['io_2ec',['io.c',['../io_8c.html',1,'']]],
  ['io_2eh',['io.h',['../io_8h.html',1,'']]]
];
