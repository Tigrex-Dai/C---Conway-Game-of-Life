var searchData=
[
  ['affiche_5fgrille',['affiche_grille',['../io_8c.html#a3f2921859f154a60f5809eb479996d42',1,'affiche_grille(grille g, int vieillissement):&#160;io.c'],['../io_8h.html#a3f2921859f154a60f5809eb479996d42',1,'affiche_grille(grille g, int vieillissement):&#160;io.c']]],
  ['affiche_5fligne',['affiche_ligne',['../io_8c.html#a64db5c037945ae6d82896b085ab3c0c8',1,'affiche_ligne(int c, int *ligne, int vieillissement):&#160;io.c'],['../io_8h.html#a64db5c037945ae6d82896b085ab3c0c8',1,'affiche_ligne(int c, int *ligne, int vieillissement):&#160;io.c']]],
  ['affiche_5ftrait',['affiche_trait',['../io_8c.html#a634cf584c380ce221d5d4199f3e813bd',1,'affiche_trait(int c):&#160;io.c'],['../io_8h.html#a634cf584c380ce221d5d4199f3e813bd',1,'affiche_trait(int c):&#160;io.c']]],
  ['alloue_5fgrille',['alloue_grille',['../grille_8c.html#ae621f51c60aa4fafaa0c9f6c9b5a4036',1,'alloue_grille(int l, int c, grille *g):&#160;grille.c'],['../grille_8h.html#ae621f51c60aa4fafaa0c9f6c9b5a4036',1,'alloue_grille(int l, int c, grille *g):&#160;grille.c']]]
];
